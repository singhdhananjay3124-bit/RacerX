plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
 namespace="com.racerx.game"
 compileSdk=35
 defaultConfig {
  applicationId="com.racerx.game"
  minSdk=24
  targetSdk=35
  versionCode=2
  versionName="2.0"
 }
}
